import static org.junit.Assert.assertArrayEquals;

import java.util.Arrays;

import org.junit.Test;

public class LagerTestUeb18 {

    @Test
    public void testSorting() {
        Lager l = new Lager(10);
        l.legeAnArtikel(new Artikel(1234,"Bli" , 100,10));
        l.legeAnArtikel(new Artikel(1245, "Bli", 100,10));
        l.legeAnArtikel(new Artikel(1276, "Bli", 100,10));
        l.legeAnArtikel(new Artikel(1202, "Bli", 100,10));
        l.legeAnArtikel(new Artikel(1277, "Bli", 100,10));
        l.legeAnArtikel(new Artikel(1134, "Bli", 100,10));
        l.legeAnArtikel(new Artikel(1734, "Bli", 100,10));

        Artikel[] sorted = l.getSorted((a, b) -> a.getArtikelNr() < b.getArtikelNr());
        
        Artikel[] real = l.getSorted((a, b) -> a.getArtikelNr() < b.getArtikelNr());
        Arrays.sort(real, (a1, a2) -> Integer.compare(a2.getArtikelNr(),a1.getArtikelNr()));

        assertArrayEquals(sorted, real);
    }

}
